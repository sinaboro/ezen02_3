package com.ezen.ex02.common;

public class LogAdvice {
	public void pringLog() {
		System.out.println("[공통 로그] 비즈니스 로직 수행 전 동작");
	}
}

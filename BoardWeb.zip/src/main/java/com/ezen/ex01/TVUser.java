package com.ezen.ex01;

import java.util.Arrays;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TVUser {

	public static void main(String[] args) {
		
		//1. Spring 컨테이너를 구동한다.
		
		AbstractApplicationContext factory = 
				new GenericXmlApplicationContext("applicationContext3.xml");
		
		TV tv = (TV)factory.getBean("lg");
		tv.volumeUp();
		
	}

}

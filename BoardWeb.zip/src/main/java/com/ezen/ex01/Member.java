package com.ezen.ex01;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Member {
	int id;
	String name;
}

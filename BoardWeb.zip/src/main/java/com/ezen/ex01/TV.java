package com.ezen.ex01;

public interface TV {
	void powerOn();
	void powerOff();
	void volumeUp();
	void volumeDown();
}

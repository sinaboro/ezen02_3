package com.ezen.ex01;

import org.springframework.stereotype.Component;

interface Speaker {
	void volumeUp();
	void volumeDown();
}

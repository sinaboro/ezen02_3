package com.ezen.ex01;

import org.springframework.stereotype.Component;

@Component
public class AppleSpeaker implements Speaker{
	public AppleSpeaker() {
		System.out.println("AppleSpeaker 생성자 스피커..");
	}
	
	public void volumeUp() {
		System.out.println("AppleSpeaker 볼륨 up");
	}
	public void volumeDown() {
		System.out.println("AppleSpeaker 볼륨 Down");
	}
}
